let previousRanks = [];

async function fetchData() {
  const res = await fetch("http://127.0.0.1:5500/top50.json");
  const data = await res.json();
  return data;
}

function decimalToHourMin(decimalHours) {
  const hrs = Math.floor(decimalHours);
  const mins = Math.round((decimalHours - hrs) * 60);
  return `${hrs}hr ${mins}min`;
}

function updateDOM(data) {
  const container = document.getElementById("predictions");

  container.innerHTML = ""; // Clear previous

  let content = "";

  // --- Sort channels by most subs gained in 24 hrs (highest first) ---
  const sortedByGains = data.slice().sort((a, b) => b.subs_gained_24hrs - a.subs_gained_24hrs);

  // --- NEW: Display Top 40 channels by subs per hour ---
  for (let i = 0; i < Math.min(10, sortedByGains.length); i++) {
    const channel = sortedByGains[i];
    const subsPerHour = Math.round(channel.subs_gained_24hrs);
    const formattedSubs = subsPerHour.toLocaleString();
    content += `${i + 1}.🔥 ${channel.name} GAINS 🢂${formattedSubs} SUBS PER HOUR \n ‎ ‎ `;
  }

  content += `\n\n`; // spacing after top list

  let any = false;

  // --- Normal prediction gap code ---
  for (let i = 0; i < data.length - 1; i++) {
    const a = data[i];
    const b = data[i + 1];
    const gap = a.subscribers - b.subscribers;
    const tinepredict = gap / 3600;

    if (gap < 500000) {
      any = true;

      content += `|🏆 THE GAP BETWEEN #${b.rank} ${b.name} & #${a.rank} ${a.name} IS ${gap.toLocaleString()} AND EXPECTED TO CHANGE WITHIN ${decimalToHourMin(tinepredict)}!\n\n\n\n\n`;
    }
  }

  if (!any) {
    content += "No close gaps found.";
  }

  container.textContent = content.trim();
}

function hasRankChanged(data) {
  const currentRanks = data.map(c => c.channel_id + "-" + c.rank);
  if (previousRanks.length === 0) {
    previousRanks = currentRanks;
    return true;
  }

  const changed = currentRanks.some((idRank, index) => idRank !== previousRanks[index]);
  previousRanks = currentRanks;
  return changed;
}

async function updatePrediction() {
  try {
    const data = await fetchData();
    if (hasRankChanged(data)) {
      updateDOM(data);
    }
  } catch (error) {
    console.error("Failed to update:", error);
  }
}

setInterval(updatePrediction, 500);
updatePrediction(); // initial call

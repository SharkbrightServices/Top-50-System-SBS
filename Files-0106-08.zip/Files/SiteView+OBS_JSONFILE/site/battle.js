const subCount = document.getElementById('subCount');
const channelName = document.getElementById('channelName');
const rankfast = document.getElementById('rankfast');

let randomNum;
let previousSubscribers = JSON.parse(localStorage.getItem('previousSubscribers')) || {};
console.log("Previous Subscribers from LocalStorage:", previousSubscribers);

let superFastChannel = false; // Control for superfast mode

do {
  randomNum = Math.floor(Math.random() * 81); // 0 to 80
} while (randomNum === 9);

async function fetchLiveData() {
    try {
        const response = await fetch('http://127.0.0.1:5500/top50.json');
        const data = await response.json();
        updateFastestGrowing(getFastestGrowing(data));

        // 🚀 Immediately re-check and restart if needed
        if (superFastChannel) {
            startTitleAndBattleSequence();
        }
    } catch (error) {
        console.error("Error fetching live data:", error);
    }

    function getsubs() {
        $.getJSON("http://127.0.0.1:5500/top50.json", (data) => {
            let totalSubscribers = 0;
            let totalSubscribersGained = 0;

            data.forEach((channel) => {
                totalSubscribers += channel.subscribers;
                const previousCount = previousSubscribers[channel.name] || 0;
                const subscribersGained = channel.subscribers - previousCount;


                if (subscribersGained > 0) {
                    totalSubscribersGained += subscribersGained;
                }

                previousSubscribers[channel.name] = channel.subscribers;
            });

            localStorage.setItem('previousSubscribers', JSON.stringify(previousSubscribers));

            if (subCount) {
                subCount.textContent = totalSubscribersGained;
            }

            console.log("📊 Total Subscribers:", totalSubscribers.toLocaleString());
            console.log("📊 Subscribers Gained (24h):", totalSubscribersGained.toLocaleString());
        });
    }

    getsubs();
}

function getFastestGrowing(data) {
    return data
        .map(channel => {
            const previousCount = previousSubscribers[channel.name] || 0;
            const subscribersGained = channel.subscribers - previousCount;
            const subsPerHour = channel.subs_gained_24hrs;
            return { ...channel, subsPerHour };
        })
        .filter(channel => channel.subsPerHour >= 5000) // Filter channels growing at least 5k+/hour
        .sort((a, b) => b.subsPerHour - a.subsPerHour);
}

function updateFastestGrowing(fastestGrowing) {
    const container = document.querySelector('.fastest-growing-wrapper');
    if (!container) return;

    container.innerHTML = '';

    superFastChannel = false; // Reset before checking

    if (fastestGrowing.length === 0) {
        container.innerHTML = '<div class="no-growth">No channels growing 5k+ per hour currently.</div>';
        return;
    }

    fastestGrowing.forEach(channel => {
        if (channel.subsPerHour >= 50000) {
            superFastChannel = true;
        }

        const card = `
            <div class="fast-card">
                <img src="${channel.pfp}" alt="">
                <div class="info">
                    <div class="name">${channel.name}</div>
                    <div class="growth">${channel.subscribers.toLocaleString()} |  ${channel.subsPerHour.toLocaleString()} subs/hour</div>
                </div>
            </div>
        `;
        container.innerHTML += card;
    });
}

function checkForBattles(data) {
    let battles = [];

    for (let i = 0; i < data.length; i++) {
        for (let j = i + 1; j < data.length; j++) {
            let diff = Math.abs(data[i].subscribers - data[j].subscribers);

            if (diff <= 30000) {
                let emoji = "";
                if (diff >= 25000 && diff <= 30000) {
                    emoji = "🎯";
                } else if (diff >= 15000) {
                    emoji = "🎈";
                } else if (diff >= 9000) {
                    emoji = "🔥";
                } else {
                    emoji = "💀";
                }

                battles.push({
                    channelA: data[i],
                    channelB: data[j],
                    rankA: i + 1,
                    rankB: j + 1,
                    diff: diff,
                    emoji: emoji
                });
            }
        }
    }

    battles.sort((a, b) => a.diff - b.diff);

    $(".battle-notifications").empty();

    battles.forEach((battle) => {
        let card = `
        <div class="battle-card">
          <div class="channel">
            <img src="${battle.channelA.pfp}" alt="">
            <div class="info">
<div class="name">${battle.channelA.name.length > 15 ? battle.channelA.name.slice(0, 10) + ".." : battle.channelA.name}</div>
              <div id="subA" class="sub">${battle.channelA.subscribers.toLocaleString()}</div>
            </div>
          </div>

          <div class="center">
            <div class="rank-badges">
              <div class="rank">#${battle.rankA}</div>
                <div class="rank">SUB GAP</div>

              <div class="rank">#${battle.rankB}</div>
            </div>
            <div class="gap">${battle.diff.toLocaleString()}</div>
          </div>

          <div class="channel">
            <div class="info" style="text-align:right;">
<div class="name">${battle.channelB.name.length > 15 ? battle.channelB.name.slice(0, 10) + ".." : battle.channelB.name}</div>
              <div class="sub">${battle.channelB.subscribers.toLocaleString()}</div>
            </div>
            <img src="${battle.channelB.pfp}" alt="">
          </div>
        </div>
        `;
        $(".battle-notifications").append(card);
    });
}

function update() {
    $.getJSON("http://127.0.0.1:5500/top50.json", (data) => {
        checkForBattles(data);
        fetchLiveData();


    });
}

function startTitleAndBattleSequence() {
    const top50Title = document.getElementById('top50-title');
    const battleNotifications = document.querySelector('.battle-notifications');
    const fastestGrowing = document.querySelector('.fastest-growing-wrapper');

    if (superFastChannel) {
        console.log("🚀 Super fast channel detected (50k+/h)! Showing ONLY Fastest Growing screen.");

        top50Title.style.display = 'none';
        battleNotifications.style.display = 'none';
        fastestGrowing.style.display = 'flex';

        setTimeout(() => {
            startTitleAndBattleSequence();
        }, 60000); // Check again every minute
    } else {
        top50Title.style.display = 'block';
        battleNotifications.style.display = 'none';
        fastestGrowing.style.display = 'none';

        const randomDelay = Math.floor(Math.random() * (120000 - 30000 + 1)) + 30000;
        console.log(`⌛ Showing TOP 50 for ${randomDelay / 1000} seconds...`);

        setTimeout(() => {
            top50Title.style.display = 'none';
            battleNotifications.style.display = 'flex';
            fastestGrowing.style.display = 'none';

            console.log("✅ Showing Battle Notifications!");

            const randomBattleDelay = Math.floor(Math.random() * (120000 - 30000 + 1)) + 30000;
            console.log(`⌛ Showing Battles for ${randomBattleDelay / 1000} seconds...`);

            setTimeout(() => {
                startTitleAndBattleSequence();
            }, randomBattleDelay);
        }, randomDelay);
    }
}

update();
startTitleAndBattleSequence();

setInterval(update, 3000);

setTimeout(() => {
    $('.loader').fadeOut();
    $('.upcoming-battles-wrapper').fadeIn(1000);
}, 1000);

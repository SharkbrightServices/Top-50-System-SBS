var c = 1;
let previousOrder = [];
let previousPositions = {};

for (var l = 1; l <= 5; l++) {
  var htmlrow = `<div class="row_${l} row"></div>`;
  $('.counters').append(htmlrow);
  for (var t = 1; t <= 10; t++){

    let number;
    if (c === 50) {
      number = `<div class="cnb">${c}</div>`;
    } else if (c === 1) {
      number = `<div class="cnb">${c}</div>`;  
    } else if (c.toString().length == 1) {
      number = `<div class="cnb">0 ${c}</div>`;  
    } else {
      number = `<div class="cnb">0 ${c}</div>`;  
    }
    var htmlcard = `<div class="channel_${c} card" id="card_thing_${c}"style="opacity: 0;">
      <div class="cnb" id="cnb_${c}">${c}</div>
      <img src="SB.png" alt="" class="cimg">
      <div class="chnam">loading...</div>
      <div class="subscriberCount odometer">0</div>
      <div class="diffcard" id="diffcardget_${c}" style="opacity: 1; display: none;">
      <img src="gain.png" id="img${c}" class="gain" style="opacity: 1;">
      <div class="subdiff" id="diff_${c}" style="font-size: 1.3em; -webkit-text-stroke: 0.1px white; color:rgb(5, 156, 10); font-weight: bold; margin-top: -32px;  margin-left: 50px; "></div>

      </div>
    </div>`;
    $('.row_' + l).append(htmlcard);
    c += 1;
  }
}

$(document).ready(function () {
  for (let i = 1; i <= 50; i++) {
    setTimeout(function () {
      $('#card_thing_' + i).fadeTo(200, 1);
    }, i * 500);
  }
});

function updateData(q, data) {
  var cnb = q + 1;
  const channelName = data[q].name;
  const cardId = "#card_thing_" + cnb;
  const cnbId = "#cnb_" + cnb;
  const diffEl = $(`#diff_${cnb}`);
  const diffcard = $(`#diffcardget_${cnb}`);
  const imgthing = $(`#img${cnb}`);
  const prevRank = previousPositions[channelName];
  const currentRank = cnb;
  let rankChangeClass = "";
/// remove the gain thing
diffEl.hide();
imgthing.hide();
diffcard.hide();
if (q < data.length - 1) {
  const nextSubs = data[q + 1].subscribers;
  const diff = data[q].subscribers - nextSubs;
  if (diff < 5000) {
    imgthing.show();
    diffcard.show();
    const formattedDiff = diff >= 1000 ? `‎ ‎ ‎ ‎ ‎ ‎ +${(diff / 1000).toFixed(1)}K` : `+${diff}`;
    diffEl.text(formattedDiff).show();
  }  else if (diff <= 100000) {
    diffEl.hide();
    imgthing.hide();
    diffcard.show();
    } else {
    diffEl.hide();
    imgthing.hide();
    diffcard.hide();



}
} else {
  imgthing.hide();
  diffcard.hide();

  diffEl.hide();


}
  if (prevRank !== undefined) {
    if (currentRank < prevRank) {
      rankChangeClass = "rank-up";
    } else if (currentRank > prevRank) {
      rankChangeClass = "rank-down";
    }
  }

// === Milestone Check & Animation ===
const previousSubs = previousOrder[q] || 0;
const currentSubs = data[q].subscribers;

function checkMilestone(prev, current) {
  const prevMilestone = Math.floor(prev / 1_000_000);
  const currMilestone = Math.floor(current / 1_000_000);
  return currMilestone > prevMilestone;
}

if (checkMilestone(previousSubs, currentSubs)) {
  const nameEl = cardSelector.find(".chnam");
  const cnbEl = cardSelector.find(".cnb");
  const subCountEl = cardSelector.find(".subscriberCount");

  // Hide normal elements
  nameEl.hide();
  cnbEl.hide();
  subCountEl.hide();

  // Apply milestone background
  cardSelector.css({
    backgroundImage: "url('milestone.gif')", // Replace with your actual path
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    transition: "background-image 0.5s ease-in-out",
  });

  // Optional overlay text
  const milestoneMessage = $('<div>', {
    class: 'milestone-message',
    html: `Milestone Reached!`,
    css: {
      fontSize: '1.5em',
      fontWeight: 'bold',
      color: '#fff',
      textShadow: '2px 2px 5px #000',
      textAlign: 'center',
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      zIndex: 10
    }
  });

  cardSelector.css('position', 'relative').append(milestoneMessage);

  // Revert after 5 seconds
  setTimeout(() => {
    cardSelector.css('background-image', '');
    milestoneMessage.remove();
    nameEl.show();
    cnbEl.show();
    subCountEl.show();
  }, 5000);
}


  $(cardId + " .cimg").attr("src", data[q].pfp);
  $(cardId + " .chnam").html(channelName);
  $(cardId + " .subscriberCount").html(Math.floor(data[q].subscribers));

  const gain = data[q].subs_gained_24hrs || 0;
  const cardElem = document.getElementById("card_thing_" + cnb);

  let bgImage = "";
  let textColor = "#000000";
  let cardColor = "#1e1e1e";
  let borderColor = "#444";

  if (gain < 0) {
    bgImage = "decrease.png";
    textColor = "#FB7029"; 
    cardColor = "#330000"; 
    borderColor = "#660000"; 
} else if (gain === 0) {
    bgImage = "deadchannel.gif";
    textColor = "#ffffff"; 
    cardColor = "#ffffff"; 
    borderColor = "#333333"; 
} else if (gain <= 399) {
    bgImage = "idle.png";
    textColor = "#000000"; 
    cardColor = "#400000"; 
    borderColor = "#800000"; 
}
// rest of your else ifs stay the same...
else if (gain <= 400) {
    bgImage = "1000.png";
    textColor = "#E59F32"; // soft light red
    cardColor = "#400000"; // dark red
    borderColor = "#800000"; // medium dark red
  } else if (gain <= 1000) {
    bgImage = "1000.png";
    textColor = "#E59F32"; // soft light red
    cardColor = "#400000"; // dark red
    borderColor = "#800000"; // medium dark red
  } else if (gain <= 2000) {
    bgImage = "2000.png";
    textColor = "#A73814"; // pinkish white
    cardColor = "#5c0000"; // deeper dark red
    borderColor = "#b30000"; // bright deep red
  } else if (gain <= 5000) {
    bgImage = "red_light_fire.gif";
    textColor = "#ffffff"; // white text
    cardColor = "#660000"; // dark maroon
    borderColor = "#ff6666"; // light fire red
  } else if (gain <= 10000) {
    bgImage = "red_dark_fire.gif";
    textColor = "#ffcccc"; // faded pink
    cardColor = "#330000"; // very dark red
    borderColor = "#990000"; // deep red
  } else if (gain <= 15000) {
    bgImage = "yellowfire.gif";
    textColor = "#ffffcc"; // pale yellow
    cardColor = "#333300"; // olive dark
    borderColor = "#cccc00"; // muted yellow
  } else if (gain <= 20000) {
    bgImage = "redextremefire.gif";
    textColor = "#ffd9f7"; // pinkish white
    cardColor = "#2b001a"; // deep purple red
    borderColor = "#ff66cc"; // neon pink
  } else if (gain <= 35000) {
    bgImage = "greenfire.gif";
    textColor = "#ccffff"; // pale cyan
    cardColor = "#001a33"; // deep blue
    borderColor = "#3399ff"; // soft blue
  } else if (gain <= 50000) {
    bgImage = "blue_fire.gif";
    textColor = "#ffffff"; // pure white
    cardColor = "#001f3f"; // dark navy blue
    borderColor = "#66ccff"; // soft blue
  } else if (gain <= 75000) {
    bgImage = "purple_fire.gif";
    textColor = "#f5e6ff"; // light purple
    cardColor = "#2b0033"; // dark purple
    borderColor = "#b366ff"; // lavender purple
  } else if (gain <= 100000) {
    bgImage = "rainbow_fire.gif";
    textColor = "#ffffff"; // white
    cardColor = "#1a1a1a"; // blackish grey (neutral for rainbow)
    borderColor = "#cccccc"; // silver
  } else {
    bgImage = "ringfire.gif";
    textColor = "#ffffcc"; // pale yellow
    cardColor = "#333300"; // dark olive green
    borderColor = "#ffff66"; // bright yellow
  }

  console.log("Updating The Subscribers Effect!")
  $(cnbId).css({
    "opacity": 0,

  });
  setInterval(3000)
  $(cnbId).css({
    "opacity": 1,
    "background-image": `url('${bgImage}')`,
    "background-size": "cover",
    "background-repeat": "no-repeat",
    "background-position": "center",
    "color": textColor,
  });

  // Update subs text (optional class inside your card)

  // Style the actual card element with color and borders
  if (cardElem) {
  //  cardElem.style.backgroundColor = cardColor;
    //cardElem.style.border = `2px solid ${borderColor}`;
    cardElem.style.color = textColor;
   // cardElem.style.boxShadow = `0 0 12px ${borderColor}`;
  }
  





  //document.getElementById("card_thing_" + cnb).style.backgroundColor = "#2ac9fe";


  if (rankChangeClass) {
    const card = $(cardId);
    card.addClass(rankChangeClass);
    setTimeout(() => card.removeClass(rankChangeClass), 800);
  }

  previousPositions[channelName] = currentRank;

  $(cardId).css("background-color", "#fceff0");
  setTimeout(() => {
    $(cardId).css("background-color", "#ffffff");
  }, 1500);
}

function showOverlay() {
  $('.update-overlay').fadeIn(300);
}

function hideOverlay() {
  const loadingget = $(`#loading`);
  setTimeout(7000);
  loadingget.hide(console.log("loadded"));}

  function update() {
    $.getJSON("http://127.0.0.1:5500/top50.json", (data) => {
      const currentOrder = data.map(channel => channel.name);
      let totalSubscribers = data.reduce((sum, channel) => sum + Math.floor(channel.subscribers), 0);
      console.log("📈 Total Subscribers:", totalSubscribers.toLocaleString());
  
      if (previousOrder.length > 0) {
        let rankChanged = false;
        for (let i = 0; i < currentOrder.length; i++) {
          if (currentOrder[i] !== previousOrder[i]) {
            rankChanged = true;
            break;
          }
        }
  
        if (rankChanged) {
          console.log("🔁 Rank has changed! Reloading page...");
          console.log("🕒 Previous Order:", previousOrder);
          console.log("📊 Previous Positions:", previousPositions);
          location.reload();
          return;
        }
      }
  
      // Update random cards
      const randomIndices = Array.from({ length: 100 }, (_, i) => i); // create an array [0, 1, 2, ..., 49]
      shuffleArray(randomIndices); // Randomize the indices
  
      for (let q = 0; q < 50; q++) {
        const randomIndex = randomIndices[q];
        setTimeout(() => {
          updateData(randomIndex, data);
        }, q * 10);
      }
  setTimeout(3000)
      previousOrder = currentOrder;
    });
  }
  
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      setInterval(20);
      [array[i], array[j]] = [array[j], array[i]]; // Swap elements
    }

    
  }
  

update();
console.log("🕒 Previous Order:", previousOrder);
setInterval(update, 8000);

setTimeout(function () {
  showOverlay();
  $('.loading').fadeIn(3000);
  $('.counters').fadeIn(3000);
hideOverlay();
}, 6000);
